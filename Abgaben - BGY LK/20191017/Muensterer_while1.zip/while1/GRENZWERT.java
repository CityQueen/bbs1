package while1;
import java.util.*;

public class GRENZWERT {

	public static void main(String[] args) {
		int grenz = 0;
		int erg = 1;
		int i = 2;
		Scanner sc = new Scanner(System.in);
		System.out.print("geben sie den Grenzwert ein: ");
		grenz = sc.nextInt();
		while (erg < grenz){
			erg = erg + i;
			i++;
		}	
		i--;
		System.out.println("Nach " + i + " Gliedern ist der Grenzwert Erreicht. Summe: " + erg);
	}

}
