package while1;

public class WildBestand {

	public static void main(String[] args) {
		int best = 200;
		int jahr = 2010;
		while(best<299) {
			best = (int) (best*1.10-15);
			System.out.println("Im Jahr " + jahr + " sind es " + best + " Wesen");
			jahr++;
		}

	}

}
