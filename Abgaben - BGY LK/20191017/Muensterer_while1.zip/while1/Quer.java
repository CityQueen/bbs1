package while1;
import java.util.*;

public class Quer {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welche Zahl m�chten sie f�r n ?");
		int n = sc.nextInt();
		int k = 0;
		int quer = 0;

		if (n <= 0) {
			System.out.println("Ihre Zahl ist nicht Valide.");
		} else {
			k = n;
			while (k > 0) {
				quer += k % 10;
				k /= 10;
			}
			System.out.println("Die quersumme von " + n + " ist das Ergebnis " + quer);
		}
	}

}
