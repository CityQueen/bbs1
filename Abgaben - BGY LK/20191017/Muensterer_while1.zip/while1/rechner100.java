package while1;

public class rechner100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int zahl = 1;
		int nenner = 1;
		while (nenner<50) {
		 System.out.println(zahl + nenner);
		 nenner++;
		 zahl++;
		}
		}
	
		
		 
		 
		{ 
		
		
	}

}
