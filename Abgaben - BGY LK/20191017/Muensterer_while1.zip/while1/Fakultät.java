package while1;
import java.util.*;
public class Fakult�t {

	public static void main(String[] args) {
		int i = 1;
		double erg=1;
		while(i<=7) {
			erg=erg*i;
			i++;
		}
	System.out.println(erg);
	}

}
