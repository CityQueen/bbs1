package while1;

public class Zufall {

	public static void main(String[] args) {
		int zahl = 0;
		int count = 1;
		while (zahl!=6) {
			zahl = (int)(Math.random() * 6 + 1);
			System.out.println("Versuch Nummer: "+ count + " Es wurde eine " + zahl + " gew�rfelt");
			count++;
		}
		System.out.println("Gl�ckwunsch!!! Du hast eine 6 gew�rfelt");
	}

}
