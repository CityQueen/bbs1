while True:
  print('Geben sie den Zinssatz an!')
  print('Geben sie "0" zm verlassen An!')
  op = int(input())
  if op == 0:
    break
  else:
    print('Bitte Geben sie das Startkapiatal an!')
    kap = int(input())
    print('Bitte geben sie eine zaufzeit in Jahren an!')
    y = int(input())
    print((kap*(op/100))*y,'€ nach',y,'Jahre(n)')
  print()