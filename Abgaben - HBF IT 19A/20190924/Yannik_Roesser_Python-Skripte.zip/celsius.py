while True:
  print('Wähle eine Operation:')
  print('1: °C -> °F')
  print('2: °F -> °C')
  print('0: Exit')
  op = int(input())
  if op == 0:
    break
  else:
    print()
  print('Temperatur:')
  t = int(input())
  print()
  if op == 1:
    print(t,'°C =',(t*(9/5)) + 32,'°F')
  elif op == 2:
    print(t,'°F =',(t-32)*(5/9),'°C')
  else:
    print('Ungültige Eingabe!')
print()