while True:
  print('Was Wollen sie Ausrechnen?')
  print('1: Umfang')
  print('2: Fläche')
  print('3: Beides')
  print('0: Exit')
  print('Bitte Wählen!')
  op = int(input('Operation: '))
  if op == 0:
    break
  else:
    print()
  print('Seite 1: ')
  l = int(input())
  print('Seite 2: ')
  b = int(input())
  if op == 1:
    print('Der Umfang ist:', 2*l + 2*b)
  elif op == 2:
    print('Die Fläche ist:', l*b)
  elif op == 3:
    print('Der Umfang ist:', 2*l + 2*b)
    print('Die Fläche ist:', l*b)
  else:
    print('Ungültige Eingabe!')
print('')

