while True:
  print('Operation Auswählen:')
  print('1: 19%')
  print('2:  7%')
  print('0: Exit')
  i = int(input())
  if i == 0:
    break
  else:
    print('Geben sie den Preis ohne Steuern an:')
    inp = int(input())
    if i == 1:
      print(inp+(inp*0.19),'€')
    elif i == 2:
      print(inp+(inp*0.07),'€')
    else:
      print('Ungültige Eingabe!')
print()