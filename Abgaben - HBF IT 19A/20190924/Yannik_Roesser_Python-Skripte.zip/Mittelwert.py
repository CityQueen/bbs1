while True:
  print('Bitte Geben sie 4 Zahlen an um den Mittelwert zu brechnen!')
  print('Zahl 1:')
  z1 = int(input())
  print('Zahl 2:')
  z2 = int(input())
  print('Zahl 3:')
  z3 = int(input())
  print('Zahl 4:')
  z4 = int(input())
  print('Der Mittelwert ist:',(z1+z2+z3+z4)/4)
  print()
  print('Wiederholen: 1')
  print('Beenden:     2')
  op = int(input())
  if op == 2:
    break
  else:
    print()
